import java.util.*;
class ArbolNario
{
private class NodoArbol
  {
    String nombre;
    NodoArbol hijo;
    NodoArbol hermano;
    NodoArbol(String elNombre,NodoArbol elHijo, NodoArbol elHermano)
    { nombre = elNombre; hijo=elHijo; hermano=elHermano;}
  }
 private NodoArbol root;
 public ArbolNario(){root=null;}
 void Preorder(){preorder(root);}
 void Postorder() {postorder(root);}
 void Inorder() {inorder(root);}
 void Imprimir() { imprime(root," ");}
 boolean Agregar(String elPath,String elDato)
 {if(root == null) {root = new NodoArbol(elDato,null,null); return true;}
    else { NodoArbol tmp = buscaNodo(elPath);
    if(tmp == null) return false;
    else return AgregaHermano(tmp,elDato);
  }
 }

 private void preorder(NodoArbol n)
 {
   //----Implementar-----------------
 }
 private void postorder(NodoArbol n)
 {
  //----Implementar-----------------
 }
 private void inorder(NodoArbol n)
 {
   //----Implementar-----------------
 }

 private NodoArbol buscaNodo(String elPath)
 {
   NodoArbol tmp1= root;
   NodoArbol tmp2 = tmp1;
   StringTokenizer path = new StringTokenizer(elPath,"/");
   String s;
   while(path.hasMoreTokens())
    { s = path.nextToken();
      while(tmp1 !=null)
      {
       if(s.equalsIgnoreCase(tmp1.nombre))  break;
          else {tmp2 = tmp1= tmp1.hermano;}
      }
      if(tmp1 == null) return tmp1;
       else {tmp2 = tmp1;tmp1 = tmp1.hijo;}
     }
     return tmp2;
   }
 
 private boolean AgregaHermano(NodoArbol elPadre, String elDato)
 {
  NodoArbol tmp=elPadre.hijo;
    if(tmp == null) { elPadre.hijo=new NodoArbol(elDato,null,null); 
                      return true;
                    }
     else {elPadre.hijo = new NodoArbol(elDato,null, elPadre.hijo); 
           return true;
          }
   }
private void imprime(NodoArbol r, String tab)
  {
   if (r!=null)
   { System.out.println(tab + r.nombre);
     imprime(r.hijo, tab +"  "); 
     imprime(r.hermano,tab);
   }  
  } 
 }//Fin clase 
