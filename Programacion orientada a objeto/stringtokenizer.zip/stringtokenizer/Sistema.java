/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringtokenizer;

import java.util.LinkedList;
import java.util.StringTokenizer;

/**
 *
 * @author object
 */
public class Sistema {
 
    public static void main(String[] args) {
        LinkedList<Auto> misAutos = new LinkedList();
        
        Auto a1 = new Auto("patente1","peugeot",4);
        misAutos.add(a1);
        Auto a2 = new Auto("patente2","mazda",3);
        misAutos.add(a2);
        Auto a3 = new Auto("patente3","toyota",2);
        misAutos.add(a3);
        int acumulador=0;
        for (int i = 0; i < misAutos.size(); i++) {
            Auto autito = misAutos.get(i);
            StringTokenizer tokenizer = new StringTokenizer(autito.toString(), "/");
            int cont = 0;
            while (tokenizer.hasMoreElements()) {
                String nextElement = (String) tokenizer.nextElement();
                System.out.println(nextElement);
                cont++;
                if (cont == 3) {
                    int numero = Integer.parseInt(nextElement);
                    acumulador += numero;
                }
            }
            
        }
        System.out.println("Acumulador: "+acumulador);
    }
}
