/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploasociacion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Vector;

/**
 *
 * @author object
 */
public class Libro {
    //Atributos
    private String nombre;
    private int nroPagina;
    private String genero;
    
    //Relaciones
    private LinkedList<Autor> misAutores;

    //Constructor
    public Libro() {
        misAutores = new LinkedList<>();
    }

    public Libro(String nombre, int nroPagina, String genero) {
        misAutores = new LinkedList<>();
        this.nombre = nombre;
        this.nroPagina = nroPagina;
        this.genero = genero;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public void cambiarGenero(String nuevoGenero) {
        genero = nuevoGenero;
    }
    
    public void agregarAutor(Autor autor){
        misAutores.add(autor);
    }

    @Override
    public boolean equals(Object object) {
        if(object instanceof Libro){
            Libro otroLibro = (Libro) object;
            return this.nombre.equals(otroLibro.obtenerNombre());
        }
        return false;
    } 
}
