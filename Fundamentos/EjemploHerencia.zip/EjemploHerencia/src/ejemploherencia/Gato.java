package ejemploherencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author object
 */
public class Gato extends Mamifero {
    private String habilidadParaCazar;
    private int longitudCola;

    public Gato(String sexo, int edad, int peso, int periodoDeGestacion, int tamañoCamada,String tipoDeDientes, String habilidadParaCazar, int longitudCola) {
        super(sexo, edad, peso, periodoDeGestacion, tamañoCamada,tipoDeDientes);
        this.habilidadParaCazar = habilidadParaCazar;
        this.longitudCola = longitudCola;
    }

    public String obtenerHabilidadParaCazar() {
        return habilidadParaCazar;
    }

    public void cambiarHabilidadParaCazar(String habilidadParaCazar) {
        this.habilidadParaCazar = habilidadParaCazar;
    }

    public int obtenerLongitudCola() {
        return longitudCola;
    }

    public void cambiarLongitudCola(int longitudCola) {
        this.longitudCola = longitudCola;
    }

    
}
