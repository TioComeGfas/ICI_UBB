/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busarchivo;

/**
 *
 * @author object
 */
public class Bus {
    private String patente;
    private int nroMaximoAsientos;
    private int nroAsientosOcupados;

    public Bus(String patente, int nroMaximoAsientos) {
        this.patente = patente;
        this.nroMaximoAsientos = nroMaximoAsientos;
    }

    public String obtienePatente() {
        return patente;
    }

    public int obtieneNroAsientos() {
        return nroMaximoAsientos;
    }

    public int obtineNroAsientosdisponibles() {
        return nroMaximoAsientos-nroAsientosOcupados;
    }
    
    public boolean ocupaAsiento(int cantidad){
        if(nroAsientosOcupados>=nroMaximoAsientos){
            return false;
        }
        nroAsientosOcupados+=cantidad;
        return true;
    }
    
    public boolean liberaAsiento(int cantidad){
        if(nroAsientosOcupados<=0){
            return false;
        }
        nroAsientosOcupados-=cantidad;
        return true;
    }
    
}
