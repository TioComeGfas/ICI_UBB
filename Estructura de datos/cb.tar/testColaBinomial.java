class testColaBinomial{
  public static void main(String[] args)
 {
 ColaBinomial b = new ColaBinomial();
 for (int i=1; i <= 13;  i++) b.Insert(i);
 b.Print();
 } 
 }
