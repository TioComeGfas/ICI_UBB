/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploasociacion;

import java.util.LinkedList;

/**
 *
 * @author object
 */
public class Autor {
    //Atributos
    private String nombre;
    private String email;
    
    //Relaciones
    private LinkedList<Libro> misLibros;
    
    //Constructor

    public Autor(String nombre, String email) {
        misLibros =  new LinkedList<>();
        this.nombre = nombre;
        this.email = email;
    }

    public void cambiarEmail(String nuevoEmail) {
        this.email = nuevoEmail;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public String obtenerEmail() {
        return email;
    }
    
    public void agregarLibro(Libro libro){
        misLibros.add(libro);
        libro.agregarAutor(this);
    }
    
    public void eliminarLibro1(Libro libro){
        for (int i = 0; i < misLibros.size(); i++) {
            Libro lib = misLibros.get(i);
            if (lib.obtenerNombre().equals(libro.obtenerNombre())) {
                misLibros.remove(i);
            }
            
        }        
    }
    
    public void eliminarLibro2(Libro libro){
        misLibros.remove(libro);
    }
    
    public String[] obtenerTitulosLibros(){
        String[] nombresLibros = new String[misLibros.size()];
        for (int i = 0; i < misLibros.size(); i++) {
            Libro lib = misLibros.get(i);
            nombresLibros[i]=lib.obtenerNombre();
        }
        return nombresLibros;
    }
    
}
