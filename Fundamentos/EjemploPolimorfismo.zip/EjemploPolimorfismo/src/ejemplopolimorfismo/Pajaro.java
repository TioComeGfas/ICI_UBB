/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplopolimorfismo;

/**
 *
 * @author object
 */
public class Pajaro extends Mascota {
    //Atributos
    private int largoAlas = 3;
    
    //Metodos
    
    @Override
    protected void alimentar(Alimento ali){
        
            AlimentoPajaro aliP = ((AlimentoPajaro) ali);
            aliP.sacarDelBolsa();
        
    }

    public int obtenerLargoAlas() {
        return largoAlas;
    }

    public void cambiarLargoAlas(int largoAlas) {
        this.largoAlas = largoAlas;
    }
    
    
    
    
    public static void main(String[] args) {
        Pajaro p1 = new Pajaro();
        AlimentoPerro aliPe = new AlimentoPerro();
        p1.alimentar(aliPe);
        
        
    }
    
}
