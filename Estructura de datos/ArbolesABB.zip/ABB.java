// Arbol de binario de búsqueda (ABB)
public class ABB { 
  private nodoABB laRaiz;
//=====Métodos publicos======================
 //constructor
  public ABB() {
    laRaiz = null;
  } 
  
// Inserta un elemento en el ABB
 public void Insertar(int elemento){
  if (laRaiz==null) laRaiz = new nodoABB(elemento,null,null);
     else inserta(laRaiz,elemento);
 }
// Elimina un elemento del ABB
public void Eliminar(int elemento) {
   laRaiz=elimina(laRaiz,elemento);
 }
// Imprime el ABB
 public  void Imprimir() {
    imprime(laRaiz, " ");
 }

//======= Metodos a implementar por usted ==== 
 public boolean Buscar(int e) {
 // ---implementar ----- 
   return true; // este return es solo para que compile...quitarlo
 } 
 public boolean SumaCero(int e) { 
 // Verifica si existe un elemento x en el ABB tal que e+x =0
  return true; // este return es solo para que compile...quitarlo
 }
 public void Postorder() { 
//Recorrido en postorder de los elementos en el ABB
//---implementar ------
 } 
 public int  Minimo() { // Modificar para manejar excepcón
 // Retorna menor valor (elemento) almacenado en el ABB. 
 // Si el ABB es ta vacio, lanzar una excepción.
 //---implementar ------
  return 0; // este return es solo para que compile...quitarlo
 } 
//==================================================

// ==============Métodos privados===================
// Imprimir el ABB
 private void imprime(nodoABB n, String tab) {
   if(n !=null) {
    System.out.println(tab+n.elemento);
    imprime(n.lchild, tab + "  ");
    imprime(n.rchild, tab + "  ");
   }
  }

//--- Supone que no existe un nodo con valor = elemento----//
 private void inserta(nodoABB n, int elemento) { 
   if(elemento < n.elemento) 
      if(n.lchild == null) n.lchild= new nodoABB(elemento,null,null);
        else inserta(n.lchild, elemento);
     else if(elemento > n.elemento)  
         if(n.rchild == null) n.rchild=new nodoABB(elemento, null, null); 
            else inserta(n.rchild, elemento);
  } 

//---- Supone que el elemento esta en el arbol----
 private nodoABB elimina(nodoABB n, int elemento) { 
   if(n.elemento == elemento) 
      if(n.lchild==null && n.rchild==null) return null;
       else if(n.lchild==null) return n.rchild;
          else if(n.rchild==null) return n.lchild;
            else {
                n.elemento=mayorElementoHijoIzquierdo(n.lchild);
                n.lchild=elimina(n.lchild,n.elemento);
              }
        else if(n.elemento > elemento) 
            n.lchild = elimina(n.lchild, elemento);
	  else 
            n.rchild = elimina(n.rchild, elemento);        
      return n;
  }
 // Obtiene el mayor elemento del subarbol izquierdo
 private int mayorElementoHijoIzquierdo(nodoABB n)
  {
   if(n.rchild==null) return n.elemento;
    else return mayorElementoHijoIzquierdo(n.rchild);
  } 

 // =================Clase nodoABB=================== 
 private class nodoABB {
  int elemento; 
  nodoABB lchild; 
  nodoABB rchild; 
  nodoABB(int elemento,nodoABB lchild, nodoABB rchild){ 
  this.elemento = elemento; 
  this.lchild = lchild; 
  this.rchild = rchild; 
 }
 void Print() {System.out.println(elemento);}
 } // fin clase NododAbb
} // Fin clase ABB
    
