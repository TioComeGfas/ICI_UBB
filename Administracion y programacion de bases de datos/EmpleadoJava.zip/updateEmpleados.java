import java.sql.*;
import java.io.*;
class updateEmpleados {
public static void main (String args []) throws IOException {    
   if(args.length !=2) { System.out.println("mode de uso: searchEmpleado id NuevoNombre"); System.exit(1);}
   int id   = new Integer(args[0]).intValue();
   Empleado e = new Empleado();
   RandomAccessFile file= new RandomAccessFile("empleados.dat","rw");
   long end = file.length(); 
   long pos=  (long) (id-1)*e.size();
   if(pos >= end) {System.out.println("No existe empleado con id " + id); System.exit(1);}
   Empleado em = new Empleado();
   file.seek(pos);
   em.readEmpleado(file);
   em.nombre = args[1];
   file.seek(pos);
   em.writeEmpleado(file);
  file.close();
 } 
}  
