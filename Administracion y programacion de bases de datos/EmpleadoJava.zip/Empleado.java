import java.io.*;
public class Empleado{
   int id;
   String nombre; //20 char
   String apellido; // 20 char
   byte depto;
   int sueldo;
// Constructores
 Empleado() {}
 Empleado(int elId, String elNombre, String elApellido, byte elDepto, int elSueldo){ 
   id = elId;
   nombre = elNombre;
   apellido = elApellido;
   depto = elDepto;
   sueldo = elSueldo;
 } 

//Lee un empleado.
void readEmpleado(RandomAccessFile f) throws IOException { // Construye el amigo desde el archivo
   byte b1[] = new byte[20];
   byte b2[] = new byte[20];
   id = f.readInt();
   f.readFully(b1);
   nombre = new String(b1);
   f.readFully(b2);
   apellido = new String(b2);
   depto = f.readByte();
   sueldo = f.readInt();
 }

// Escribe en disco un empleado
void writeEmpleado(RandomAccessFile f) throws IOException { 
   byte b1[] = new byte[20];
   byte b2[] = new byte[20];
   f.writeInt(id);
   nombre.getBytes(0,nombre.length(),b1,0);
   f.write(b1);
   apellido.getBytes(0,apellido.length(),b2,0);
   f.write(b2);
   f.writeByte(depto);
   f.writeInt(sueldo);
 }  

// Tamaño del registor empleado|
 int size() { return 49;}

// Mostrar atributos del empleado
 void Print() {
   System.out.println(id +"\t"+ nombre + "\t" + apellido + "\t\t"+  depto + "\t" + sueldo);
 }
} 
