#include <iostream>
#include <algorithm>
#include <ctype.h>

using namespace std;

string *parser(string input, int &tam,char c){
	int aux,cont;
	string *P;
	int n = count(input.begin(), input.end(), c);
	P = new string[n+1];
	aux=0;
	cont=0;
	for(int i=0;i<input.size();i++){
		if(input[i]==c){
			P[cont]=input.substr(aux,i-aux);
			aux=i+1;
			cont++;
		}
	}
	P[cont]=input.substr(aux,input.size()-aux);
	tam = n+1;
	return P;
}

char *cparser(string input, int &tam){
	int aux,cont;
	char *P;
	int n = count(input.begin(), input.end(), ',');
	P = new char[n+1];
	for(int i=0;i<n+1;i++){
		P[i]=input[2*i];
	}
	tam = n+1;
	return P;
}

int pos(string *P,string I,int tam){
	for(int i=0;i<tam;i++){
		if(P[i]==I) return i;
	}
	return -1;
}

int cpos(char *P,char I,int tam){
	for(int i=0;i<tam;i++){
		if(P[i]==I) return i;
	}
	return -1;
}

bool error(string *Q,int sq){
	for(int i=0;i<sq;i++){
		if(isalpha(Q[i][0])==0) return true;
	}
	return false;
}

bool errorS(string input){
	for(int i=1;i<input.size();i=i+2){
		if(input[i]!=',') return true;
	}
	return false;
}

int main() {
	string input, *Q,Q0,*QF,*inst,*q;
	char *Sig;
	int sq,sa,sf,si,h,pi,pj;
	int cont,aux;
	cin >> input;
	Q = parser(input,sq,',');
	if(error(Q,sq)){
		cout << "Error en estados" << endl;
		return 0;
	}
	cin >> input;
	if(errorS(input)){
		cout << "Error en simbolos" << endl;
		return 0;
	}
	Sig = cparser(input,sa);
	cin >> Q0;
	if(pos(Q,Q0,sq)==-1){
		cout << "Error en estado inicial" << endl;
		return 0;
	}
	cin >> input;
	QF = parser(input,sf,',');
	for(int i=0;i<sf;i++) if(pos(Q,QF[i],sq)==-1){
		cout << "Error en estados finales" << endl;
		return 0;
	}
	string D[sq][sa][sq];
	cin >> input;
	inst = parser(input,si,';');
	int qis[sq][sa];
	int esta = 0;
	for(int i=0;i<sq;i++) for(int j=0;j<sa;j++) qis[i][j]=0;
	for(int i=0;i<si;i++){
		pi=pos(Q,inst[i].substr(0,inst[i].find(",")),sq);
		pj=cpos(Sig,inst[i][inst[i].find(",")+1],sa);
		if(pi==-1 || pj==-1){
			cout << "Error en transiciones" << endl;
			return 0;
		}
		for(int l=0;l<qis[pi][pj];l++) if(D[pi][pj][l].compare(inst[i].substr(inst[i].find("=")+1,inst[1].size()-(inst[i].find("=")+1)))==0) esta=1;
		if(esta==0){
			D[pi][pj][qis[pi][pj]]=inst[i].substr(inst[i].find("=")+1,inst[1].size()-(inst[i].find("=")+1));
			qis[pi][pj]++;
		}
		else esta=0;
	}
	cin >> input;
	for(int i=0;i<input.size();i++) if(cpos(Sig,input[i],sa)==-1){
		cout << "Error en entrada" << endl;
		return 0;
	}
	q = new string[sq];
	q[0]=Q0;
	string qaux[sq];
	cont = 1;
	int contaux = 1;
	for(int i=0;i<input.size();i++){
		if(i==h) cout << "_";
		cout << input[i];
	}
	cout << ",";
	for(int i=0;i<cont;i++) cout << q[i];
	cout << endl;
	esta=0;
	while(contaux>0 && h<input.size()){
		contaux=0;
		for(int i=0;i<cont;i++){
			pi=pos(Q,q[i],sq);
			pj=cpos(Sig,input[h],sa);
			for(int j=0;j<qis[pi][pj];j++){
				for(int l=0;l<contaux;l++) if(qaux[l].compare(D[pi][pj][j])==0) esta=1;
				if(esta==0){
					qaux[contaux]=D[pi][pj][j];
					contaux++;
				}
				else esta=0;
			}
		}
		if(contaux>0){
			cont = contaux;
			q = qaux;
			h++;
			for(int i=0;i<input.size();i++){
				if(i==h) cout << "_";
				cout << input[i];
			}
			if(h==input.size()) cout << "_";
			cout << ",";
			for(int i=0;i<cont;i++) cout << q[i];
			cout << endl;
		}
	}
	aux=0;
	for(int i=0;i<cont;i++){
		if(pos(QF,q[i],sf)>=0 && h==input.size()){
			cout << "Aceptado" << endl;
			aux=1;
		}
	}
	if(aux==0) cout << "Rechazado" << endl;
}
