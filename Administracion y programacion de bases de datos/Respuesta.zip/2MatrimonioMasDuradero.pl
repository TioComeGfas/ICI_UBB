DECLARE
  CURSOR matrimonios IS SELECT * FROM casados;
  matrimonio casados%ROWTYPE;
  fechaHoy DATE;
  duracion INTEGER;
  idHombre casados.idh%TYPE;
  idMujer casados.idm%TYPE;
  duracionMayor INTEGER;
  nombreMarido amigos.nombre%TYPE;
  nombreMujer amigos.nombre%TYPE;
BEGIN
  duracionMayor := 0;
  SELECT SYSDATE INTO fechaHoy FROM DUAL;
  FOR matrimonio IN matrimonios LOOP
    IF matrimonio.fechaSep IS NULL THEN
      duracion := FLOOR((fechaHoy - matrimonio.fechaCas) / 365);
    ELSE
      duracion := FLOOR((matrimonio.fechaSep - matrimonio.fechaCas) / 365);
    END IF;
    IF duracion > duracionMayor THEN
      idHombre := matrimonio.idh;
      idMujer := matrimonio.idm;
      duracionMayor := duracion;
    END IF;
  END LOOP;
  SELECT nombre INTO nombreMujer FROM amigos WHERE id = idMujer;
  SELECT nombre INTO nombreMarido FROM amigos WHERE id = idHombre;
  dbms_output.put_line('El matrimonio mas duradero es el de ' || nombreMarido || ' y ' || nombreMujer);
END;