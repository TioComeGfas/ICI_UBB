/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploasociacion;

/**
 *
 * @author object
 */
public class Sistema {
    
    public static void main(String[] args) {
        Libro lib1 = new Libro("La diarrea es mas rapida que el pensamiento", 450, "Drama");
        Libro lib2 = new Libro("Las notas de POO", 50, "Suspenso");
        Libro lib3 = new Libro("Aprobando POO", 450, "Ciencia Ficción");
        Libro lib4 = new Libro("Aprobando POO", 450, "Ciencia Ficción");
        
        Autor aut1 = new Autor("Pati cofre", "queteimporta@aiteves.com");
        Autor aut2 = new Autor("Gary Medel", "yodijequesucede@pitbullgay.cl");
        
        aut1.agregarLibro(lib1);
        aut2.agregarLibro(lib3);
        aut2.agregarLibro(lib2);
        
        String[] nomLibros = aut1.obtenerTitulosLibros();
        for (int i = 0; i < nomLibros.length; i++) {
            System.out.print(nomLibros[i]+"-");
            
        }
        //aut2.eliminarLibro2(lib4);
        System.out.println("");
        System.out.println("*********************************");
        nomLibros = aut2.obtenerTitulosLibros();
        for (int i = 0; i < nomLibros.length; i++) {
            System.out.print(nomLibros[i]+"-");
            
        }
        System.out.println("");
    }
    
}
