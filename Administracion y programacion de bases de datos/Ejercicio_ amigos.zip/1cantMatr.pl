DECLARE
  vigentes NUMBER;
  separados NUMBER;
BEGIN
  SELECT COUNT(*) INTO vigentes FROM casados WHERE fechaSep IS NULL;
  SELECT COUNT(*) INTO separados FROM casados WHERE fechaSep IS NOT NULL;
  dbms_output.put_line('Matrimonios vigentes: ' || vigentes);
  dbms_output.put_line('Matrimonios separados: ' || separados);
END;
