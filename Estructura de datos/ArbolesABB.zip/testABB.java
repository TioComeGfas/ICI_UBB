class testABB {
 public static void main(String[] args)
 {
 ABB a = new ABB();
 a.Insertar(40); 
 a.Insertar(50); 
 a.Insertar(12); 
 a.Insertar(20);
 a.Insertar(18);
 a.Insertar(2); 
 a.Insertar(4); 
 a.Insertar(11);
 a.Insertar(30);
 a.Imprimir();
 }
}
