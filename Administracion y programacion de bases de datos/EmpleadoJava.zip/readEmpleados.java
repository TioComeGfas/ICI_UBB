import java.sql.*;
import java.util.Scanner;
import java.io.*;
 class readEmpleados {
 public static void main (String args []) throws IOException {    
 RandomAccessFile in= new RandomAccessFile("empleados.dat","r");
 Empleado em=new Empleado();
  try { 
   for(;;) {
       em.readEmpleado(in);  
       em.Print();
      }
    } catch(EOFException ex) { /*No hace nada */;}
  in.close();  
 } 
}
