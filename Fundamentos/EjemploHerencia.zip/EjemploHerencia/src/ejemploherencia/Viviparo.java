package ejemploherencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author object
 */
public class Viviparo extends Animal{
    private int periodoDeGestacion;
    private int tamañoCamada;

    public Viviparo(String sexo, int edad, int peso, int periodoDeGestacion, int tamañoCamada) {
        super(sexo,edad,peso);
        this.periodoDeGestacion = periodoDeGestacion;
        this.tamañoCamada = tamañoCamada;
    }

    public int obtenerPeriodoDeGestacion() {
        return periodoDeGestacion;
    }

    public void cambiarPeriodoDeGestacion(int periodoDeGestacion) {
        this.periodoDeGestacion = periodoDeGestacion;
    }

    public int obtenerTamañoCamada() {
        return tamañoCamada;
    }

    public void cambiarTamañoCamada(int tamañoCamada) {
        this.tamañoCamada = tamañoCamada;
    }
    
    
    
}
