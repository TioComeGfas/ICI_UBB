/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringtokenizer;

/**
 *
 * @author object
 */
public class Auto {
    
    private String patente;
    private String marca;
    private int nroPuertas;

    public Auto(String patente, String marca, int nroPuertas) {
        this.patente = patente;
        this.marca = marca;
        this.nroPuertas = nroPuertas;
    }

    public String obtenerPatente() {
        return patente;
    }

    public void cambiarPatente(String patente) {
        this.patente = patente;
    }

    public String obtenerMarca() {
        return marca;
    }

    public void cambiarMarca(String marca) {
        this.marca = marca;
    }

    public int obtenerNroPuertas() {
        return nroPuertas;
    }

    public void cambiarNroPuertas(int nroPuertas) {
        this.nroPuertas = nroPuertas;
    }
    
    public String toString(){
        return patente+"/"+marca+"/"+nroPuertas;
    }
    
    
}
