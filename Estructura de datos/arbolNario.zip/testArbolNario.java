class testArbolNario {
 public static void main(String[] args)
 {
  ArbolNario a = new ArbolNario();
  a.Agregar("/","a"); 
  a.Agregar("/a","b"); 
  a.Agregar("/a","c"); 
  a.Agregar("/a","d"); 
  a.Agregar("/a/b","d"); 
  a.Agregar("/a/b","e"); 
  a.Agregar("/a/c","f"); 
  a.Agregar("/a/c","g"); 
  a.Agregar("/a/c/g","h"); 
  a.Agregar("/a/b/d","i"); 
  System.out.println("Arbol N-ario");
  a.Imprimir();
  System.out.println("Recorrido en Preorder");
  a.Preorder();
  System.out.println("Recorrido en Inorder");
  a.Inorder();
  System.out.println("Recorrido en Postorder");
  a.Postorder();
 }
}
