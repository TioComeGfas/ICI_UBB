import java.util.*;
class testSetI{
  public static void main(String[] args)
 {
  SetI A = new SetI();
  SetI B = new SetI();
  SetI C = new SetI();
  A.Agregar((byte) 5);
  A.Agregar((byte) 2);
  A.Agregar((byte) 0);
  A.Agregar((byte) 30);
  B.Agregar((byte) 2);
  B.Agregar((byte) 0);
  B.Agregar((byte) 6);
  System.out.print("Conjunto A: ");
  A.Print();
  System.out.print("Conjunto B: ");
  B.Print();
  System.out.print("Conjunto C: ");
  C.Print();
  System.out.println("6 pertence a A ? "+ A.Pertenece((byte) 6));
  System.out.println("el numero de elemenos en A es: " + A.Cardinalidad());
  System.out.println("B es subconjunto de A  ? " + B.Subconjunto(A));
  C = A.Interseccion(B);
  System.out.print("A interseccion B: ");  
  C.Print();
  C = A.Union(B);
  System.out.print("A union B: ");  
  C.Print();
 }
}
