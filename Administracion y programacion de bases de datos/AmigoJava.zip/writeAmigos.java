import java.util.Scanner;
import java.io.*;
class writeAmigos {
public static void main (String args []) throws IOException {    
   Scanner in = new Scanner(System.in);
   DataOutputStream out= new DataOutputStream(new FileOutputStream("amigos.dat",true));
   int elId, elCel; 
   String elNombre, elSexo;
   Amigo a;
   for(;;){
      System.out.println("---- datos del amigo -----");
      System.out.print("ID (-1 --> termina) :"); 
      elId = in.nextInt(); 
      if(elId<0) break;
      System.out.print("Nombre :"); 
      elNombre = in.next(); 
      System.out.print("Celular : "); 
      elCel = in.nextInt(); 
      System.out.print("Sexo (M/F): "); 
      elSexo = in.next(); 
      a = new Amigo(elId,elNombre, elCel, elSexo);
      a.writeAmigo(out);
   } 
  System.out.println("Terminado ... ");
  out.close();
 } 
}  
