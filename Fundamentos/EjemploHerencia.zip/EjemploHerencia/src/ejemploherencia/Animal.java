package ejemploherencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author object
 */
public class Animal {
    private String sexo;
    private int edad;
    private int peso;

    public Animal(String sexo, int edad, int peso) {
        this.sexo = sexo;
        this.edad = edad;
        this.peso = peso;
    }

    public String obtenerSexo() {
        return sexo;
    }

    public void cambiarSexo(String sexo) {
        this.sexo = sexo;
    }

    public int obtenerEdad() {
        return edad;
    }

    public void cambiarEdad(int edad) {
        this.edad = edad;
    }

    public int obtenerPeso() {
        return peso;
    }

    public void cambiarPeso(int peso) {
        this.peso = peso;
    }
    
    
    
}
