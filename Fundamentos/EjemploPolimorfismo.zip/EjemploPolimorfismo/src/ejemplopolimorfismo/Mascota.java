/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplopolimorfismo;

/**
 *
 * @author object
 */
public class Mascota {
    
    protected String nombre;
    protected int peso;
    
    //Metodos
    protected void alimentar(Alimento ali){
        
    }
    
}
