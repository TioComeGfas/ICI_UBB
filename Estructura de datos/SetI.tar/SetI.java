//------Conjuntos formados por elementos entre U=[0.31]  
public class SetI {
      private int s;
      SetI() {s=0;} 
      boolean EstaVacio() { 
       return s==0;
       } 
      void Agregar( byte b) { 
       s = (s | 0x80000000 >>> b);
      }  
     boolean Pertenece(byte  b ) { 
      return (s & 0x80000000 >>> b ) != 0;
    }
//----------- Union de conjuntos----
    SetI Union(SetI s1) { 
    SetI r = new SetI();
    r.s = s1.s | s; 
    return r;
   }
//---------- Intersección de conjuntos
   SetI Interseccion( SetI s1) { 
    SetI r = new SetI();
    r.s = s1.s & s; 
    return r;
   }
//---------- Complemento 
 SetI Complemento() {
    SetI r = new SetI();
    r.s = ~s; 
    return r;
}
//---------- Diferencia de conjuntos (A-B)
 SetI Diferencia(SetI s1) {
    return Interseccion(s1.Complemento()) ; 
}
//-- Cardinalidad 
byte  Cardinalidad(){ 
 byte c=0; 
 int m=0x80000000;
 for(byte i=0; i < 32 ; i++) {
  if ((s & m) !=0) c++;    
  m = m >>>1 ;
 }  
 return c;
} 
//------ A subconjunto de B
boolean Subconjunto(SetI s1) { 
 for (byte i = 0 ; i < 32; i++)
  if ((this.Pertenece(i) && !s1.Pertenece(i))) return false;
 return true;
}
boolean Iguales(SetI s1) { 
  return this.Subconjunto(s1) && s1.Subconjunto(this);
 }
//------- Imprime los elementos del conjunto ----
  void Print() {
   int m= 0x80000000;
   System.out.print("{");
   boolean f = false;
   byte c = 0;
   for(byte i=0; i < 32 ; i++){ 
     if((m & s)!=0) { 
       if (c==0) System.out.print(i);
       else System.out.print(","+i);  
       c++;
     }
     m= m >>> 1; 
   }
   System.out.println("}");
   }
}
