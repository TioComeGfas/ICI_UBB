DECLARE
  CURSOR solterisimos IS SELECT * FROM amigos WHERE sexo='M' AND id NOT IN (SELECT idh FROM casados);
  soltero amigos%ROWTYPE;
BEGIN
  dbms_output.put_line('Amigos solterisimos:');
  dbms_output.put_line('ID nombre.');
  FOR soltero IN solterisimos LOOP
    dbms_output.put_line(soltero.id || ' ' || soltero.nombre);
  END LOOP;
END;