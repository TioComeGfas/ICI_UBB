import java.io.*;
public class Amigo{
   int id;
   String nombre;
   int cel;
   String sexo;
 Amigo() {}
 Amigo(int elId, String elNombre, int elCel, String elSexo){ 
   id = elId;
   nombre = elNombre;
   cel = elCel;
   sexo = elSexo;
 } 
// Lee un amigo desde s
 void readAmigo(DataInputStream s) throws IOException {  
   id = s.readInt();
   nombre= s.readUTF();
   cel = s.readInt();
   sexo= s.readUTF();
  }
 void writeAmigo(DataOutputStream s) throws IOException { 
   s.writeInt(id);
   s.writeUTF(nombre);
   s.writeInt(cel);
   s.writeUTF(sexo);
 }  
 void Print() {
   System.out.println( id +"\t" + nombre + "\t " + cel + "   \t" + sexo);
 }
} 
