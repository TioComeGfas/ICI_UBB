/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busarchivo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import sun.util.locale.StringTokenIterator;

/**
 *
 * @author object
 */
public class Sistema {

    static LinkedList<Bus> misBuses;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        misBuses = new LinkedList();
        LinkedList<Bus> busesRevisados = new LinkedList();
        try {
            //El nombre del archivo puede especificar una ruta
            String nombreArchivo = "buses.txt";
            FileReader fr = new FileReader(nombreArchivo);
            BufferedReader bf = new BufferedReader(fr);
            String linea;
            //Se debe verificar si se llego al final del archivo, linea != null
            while ((linea = bf.readLine())!=null) {
                    String datos[] = linea.split(";");
                    int numeroMaximoDeAsientos = Integer.parseInt(datos[1]);
                    Bus bus = new Bus(datos[0], numeroMaximoDeAsientos);
                    misBuses.add(bus);
            } 
        } catch (FileNotFoundException fnfe){
                fnfe.printStackTrace();
        } catch (IOException ioe){
                ioe.printStackTrace();
        }
        
        try {
            //El nombre del archivo puede especificar una ruta
            String nombreArchivo2 = "pasajeros.txt";
            FileReader fr2 = new FileReader(nombreArchivo2);
            BufferedReader bf2 = new BufferedReader(fr2);
            String linea2;
            boolean repetido=false;
            //Se debe verificar si se llego al final del archivo, linea != null
            Bus busProcesado=null;
            while ((linea2 = bf2.readLine())!=null) {
                
                String datos[] = linea2.split(",");
                if (datos.length == 1) {
                    //Leyendo una patente
                    for (int i = 0; i < misBuses.size(); i++) {
                        busProcesado = misBuses.get(i);
                        if (busProcesado.obtienePatente().equals(linea2)) {
                            repetido = busesRevisados.contains(busProcesado);
                            if(!repetido){
                                busesRevisados.add(busProcesado);
                            }
                            System.out.println("patente: "+busProcesado.obtienePatente()+" repetido: "+repetido);
                            break;
                        }
                    }
                } else {
                    //Leyendo una acción
                    if(!repetido){
                        if(datos[0].equals("1")){
                            int numeroDePasajeros = Integer.parseInt(datos[1]);
                            boolean resultado = busProcesado.ocupaAsiento(numeroDePasajeros);
                        } else {
                            int numeroDePasajeros = Integer.parseInt(datos[1]);
                            boolean resultado = busProcesado.liberaAsiento(numeroDePasajeros);
                        }
                    }
                    
                }
            } 
        } catch (FileNotFoundException fnfe){
                fnfe.printStackTrace();
        } catch (IOException ioe){
                ioe.printStackTrace();
        }
        
        System.out.println("CAPACIDAD DISPONIBLE Y OCUPADA POR BUS");
        for (int i = 0; i < misBuses.size(); i++) {
            Bus bus = misBuses.get(i);
            System.out.println(bus.obtienePatente()+" "+bus.obtineNroAsientosdisponibles()+" "+bus.obtieneNroAsientos());
        }
    }
    
}
