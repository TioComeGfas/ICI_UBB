DECLARE
  tiempo INTEGER;
  nombreElla VARCHAR(20);
  nombreEl VARCHAR(20);
  fechaInicio DATE;
  fechaFin DATE;
  CURSOR matr IS (SELECT m.nombre, h.nombre, fechaCas, fechaSep 
    FROM (casados JOIN amigos m ON idm = m.id) 
    JOIN amigos h ON idh = h.id);
BEGIN
  OPEN matr;
  LOOP
    FETCH matr INTO nombreElla, nombreEl, fechaInicio, fechaFin;
    EXIT WHEN matr%NOTFOUND;
    IF (fechaFin IS NULL) THEN
      SELECT SYSDATE INTO fechaFin FROM DUAL;
    END IF;
    tiempo := FLOOR((fechaFin - fechaInicio) / 365);
    dbms_output.put_line(nombreElla || ' y ' || nombreEl || ' duraron '  || tiempo || ' anios');
  END LOOP;
  CLOSE matr;
END;
