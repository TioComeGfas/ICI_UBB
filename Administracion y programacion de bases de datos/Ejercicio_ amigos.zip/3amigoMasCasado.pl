DECLARE
  CURSOR vecesCasados IS 
    (SELECT COUNT(*) cantidad, idh id FROM casados GROUP BY idh)
    UNION
    (SELECT COUNT(*) cantidad, idm id FROM casados GROUP BY idm);
  id amigos.id%TYPE;
  idMasVeces amigos.id%TYPE;
  cantidad number;
  masVeces number;
  nombreAmigo amigos.nombre%TYPE;
BEGIN
  masVeces := 0;
  OPEN vecesCasados;
  LOOP
    FETCH vecesCasados INTO cantidad, id;
    EXIT WHEN vecesCasados%NOTFOUND;
    IF (cantidad > masVeces) THEN
        masVeces := cantidad;
        idMasVeces := id;
    END IF;
  END LOOP;
  CLOSE vecesCasados;
  SELECT nombre INTO nombreAmigo FROM amigos WHERE id = idMasVeces;
  dbms_output.put_line('El amigo que mas veces se ha casado es: ' ||  nombreAmigo);
END;
