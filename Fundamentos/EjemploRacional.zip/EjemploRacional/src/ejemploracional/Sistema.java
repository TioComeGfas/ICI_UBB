package ejemploracional;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author object
 */
public class Sistema {
    
    public static void main(String[] args) {
        Racional ra1 = new Racional(2, 3);
        ra1.obtenerNumerador(ra1);
        Racional ra2 = new Racional(1,3);
        Racional ra3 = ra1.sumaRac(ra1, ra2);
        System.out.println("El numerador es: "+ra3.obtenerNumerador(ra3)+" El denominador es: "+ra3.obtenerDenominador(ra3));
    }
    
}
