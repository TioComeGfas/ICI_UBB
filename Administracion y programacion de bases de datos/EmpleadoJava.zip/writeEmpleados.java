import java.sql.*;
import java.util.Scanner;
import java.io.*;
class writeEmpleados {
public static void main (String args []) throws IOException {    
   Scanner in = new Scanner(System.in);
   RandomAccessFile out= new RandomAccessFile("empleados.dat","rw");
   out.seek(out.length());
   int elId, elSueldo;
   byte elDepto;
   String elNombre, elApellido;
   Empleado e;
   for(;;){
      System.out.println("---- datos del Empleado -----");
      System.out.print("ID (-1 --> termina) :"); 
      elId = in.nextInt(); 
      if(elId<0) break;
      System.out.print("Nombre (20) :"); 
      elNombre = in.next(); 
      System.out.print("Apellido(20) :"); 
      elApellido = in.next(); 
      System.out.print("Depto : "); 
      elDepto = in.nextByte(); 
      System.out.print("Sueldo : "); 
      elSueldo = in.nextInt(); 
      e = new Empleado(elId,elNombre,elApellido, elDepto, elSueldo);
      e.writeEmpleado(out);
   } 
  System.out.println("Terminado ... ");
  out.close();
 } 
}  
