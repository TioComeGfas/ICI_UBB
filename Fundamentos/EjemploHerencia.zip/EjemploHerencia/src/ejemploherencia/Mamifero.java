package ejemploherencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author object
 */
public class Mamifero extends Viviparo{
    private String tipoDeDientes;

    public Mamifero(String sexo, int edad, int peso, int periodoDeGestacion, int tamañoCamada,String tipoDeDientes) {
        super(sexo,edad,peso,periodoDeGestacion,tamañoCamada);
        this.tipoDeDientes = tipoDeDientes;
    }

    public String obtenerTipoDeDientes() {
        return tipoDeDientes;
    }

    public void cambiarTipoDeDientes(String tipoDeDientes) {
        this.tipoDeDientes = tipoDeDientes;
    }
    
    
}
