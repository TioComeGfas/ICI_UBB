import java.io.*;
 class readAmigos {
 public static void main (String args []) throws IOException {    
 DataInputStream in= new DataInputStream(new FileInputStream("amigos.dat"));
 Amigo a=new Amigo();
  try { 
   for(;;) {
       a.readAmigo(in);  
       a.Print();
      }
    } catch(EOFException e) { /*No hace nada */;}
  in.close();  
 } 
}
