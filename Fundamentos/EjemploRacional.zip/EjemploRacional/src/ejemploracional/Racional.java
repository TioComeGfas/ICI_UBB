package ejemploracional;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author object
 */
public class Racional {
    //Atributos
    private int numerador;
    //El denominador debe ser distinto de cero 
    private int denominador;
    
    //Metodos
    //Constructor
    public Racional(int x, int y){
        if (y!=0) {
            numerador = x;
            denominador = y;
        }
    }
    
    public int obtenerNumerador(Racional a){
        return a.numerador;
    }
    
    public int obtenerDenominador(Racional a){
        return a.denominador;
    }
    
    public Racional sumaRac(Racional a, Racional b){
        int deno = a.denominador*b.denominador;
        int num = a.numerador*b.denominador+b.numerador*a.denominador;
        Racional nuevoRacional = new Racional(num, deno);
        return nuevoRacional;
    }
    
    public static void main(String[] args) {
        Racional ra1 = new Racional(2, 3);
        Racional ra2 = new Racional(1,3);
        Racional ra3 = ra1.sumaRac(ra1, ra2);
        System.out.println("El numerador es: "+ra3.obtenerNumerador(ra3)+" El denominador es: "+ra3.obtenerDenominador(ra3));
    }
}
